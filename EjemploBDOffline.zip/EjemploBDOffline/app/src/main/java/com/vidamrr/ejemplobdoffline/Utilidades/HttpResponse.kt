package com.vidamrr.ejemplobdoffline.Utilidades

interface HttpResponse {

    fun httpResponseSuccess(response: String)
}