package com.vidamrr.ejemplobdoffline.Modelo

class Alumno(id:String, nombre:String) {

    var id:String? = null;
    var nombre:String? = null;


    init {
        this.id = id;
        this.nombre = nombre;
    }

}