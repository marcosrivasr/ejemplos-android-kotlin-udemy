package com.vidamrr.ejemplobdoffline.RecyclerView

import android.view.View


interface LongClickListener {

    fun longClick(vista: View, index:Int)
}