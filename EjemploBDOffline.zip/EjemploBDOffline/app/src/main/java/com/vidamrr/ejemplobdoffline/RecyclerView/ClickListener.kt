package com.vidamrr.ejemplobdoffline.RecyclerView

import android.view.View


interface ClickListener {

    fun onClick(vista: View, index:Int)
}